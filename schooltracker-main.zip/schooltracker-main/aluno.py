class Aluno():
    def __init__(self,ra,nome,tempoestudo,rendafamiliar):
        self.ra = ra
        self.nome = nome
        self.tempoestudo = tempoestudo
        self.rendafamiliar = rendafamiliar